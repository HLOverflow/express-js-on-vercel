import { generateSwaggerFile } from '../src/swagger.config.js'

console.log('🔄 Generating Swagger documentation...')
generateSwaggerFile()
console.log('✨ Done!')
